// canvas.js — drawing engine (local + remote)
(() => {
  const canvas = document.getElementById("board");
  const cursorsLayer = document.getElementById("cursors");
  const ctx = canvas.getContext("2d");

  // resize canvas to CSS size (devicePixelRatio aware)
  function fitCanvas() {
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    ctx.scale(dpr, dpr);
    redrawAll(); // after resize, re-render history
  }
  window.addEventListener("resize", fitCanvas);
  // initial size after first paint
  requestAnimationFrame(fitCanvas);

  // tool state
  const state = {
    color: "#222222",
    size: 4,
    mode: "brush", // brush | eraser
    isDrawing: false,
    points: [], // current stroke points (local)
    strokeId: null,
    myId: null,
    users: {}, // id -> { color, name? }
    history: [], // array of strokes
  };

  // stroke helpers
  function createStrokeId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  }

  function drawStroke(ctx, stroke) {
    if (!stroke.points || stroke.points.length === 0) return;
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = (stroke.type === "erase") ? "#ffffff" : stroke.color;
    ctx.lineWidth = stroke.size;
    ctx.globalCompositeOperation = (stroke.type === "erase") ? "destination-out" : "source-over";

    const pts = stroke.points;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length - 1; i++) {
      const midX = (pts[i].x + pts[i+1].x) / 2;
      const midY = (pts[i].y + pts[i+1].y) / 2;
      ctx.quadraticCurveTo(pts[i].x, pts[i].y, midX, midY);
    }
    // last segment
    if (pts.length > 1) {
      const last = pts[pts.length - 1];
      ctx.lineTo(last.x, last.y);
    }
    ctx.stroke();
    ctx.restore();
  }

  function clearCanvas() {
    const rect = canvas.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);
  }

  function redrawAll() {
    clearCanvas();
    for (const s of state.history) drawStroke(ctx, s);
  }

  // coordinate helpers
  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const y = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
    return { x: Math.max(0, Math.min(rect.width, x)), y: Math.max(0, Math.min(rect.height, y)) };
  }

  // local draw lifecycle
  function startStroke(e) {
    e.preventDefault();
    state.isDrawing = true;
    state.points = [];
    const p = getPos(e);
    state.points.push(p);
    state.strokeId = createStrokeId();

    const stroke = {
      id: state.strokeId,
      userId: state.myId,
      color: state.color,
      size: state.size,
      type: state.mode === "eraser" ? "erase" : "draw",
      points: [p],
    };
    // draw locally (start small dot)
    drawStroke(ctx, stroke);
    // notify server
    WS.sendDrawStart(stroke);
  }

  let rafPending = false;
  function moveStroke(e) {
    if (!state.isDrawing) return;
    const p = getPos(e);
    state.points.push(p);

    // schedule local render at rAF to avoid flooding
    if (!rafPending) {
      rafPending = true;
      requestAnimationFrame(() => {
        const stroke = {
          id: state.strokeId,
          userId: state.myId,
          color: state.color,
          size: state.size,
          type: state.mode === "eraser" ? "erase" : "draw",
          points: state.points.slice(-3), // only latest segment for local incremental draw
        };
        drawStroke(ctx, stroke);
        rafPending = false;
      });
    }
    // stream point to server (throttled by socket.volatile)
    WS.sendDrawPoint({ strokeId: state.strokeId, point: p });
    // update remote cursor for me
    WS.sendCursor({ x: p.x, y: p.y });
  }

  function endStroke() {
    if (!state.isDrawing) return;
    state.isDrawing = false;

    // finalize: push full stroke to local history
    const stroke = {
      id: state.strokeId,
      userId: state.myId,
      color: state.color,
      size: state.size,
      type: state.mode === "eraser" ? "erase" : "draw",
      points: state.points.slice(),
    };
    state.history.push(stroke);
    WS.sendDrawEnd(state.strokeId);

    state.points = [];
    state.strokeId = null;
  }

  // attach mouse/touch
  canvas.addEventListener("mousedown", startStroke);
  canvas.addEventListener("mousemove", moveStroke);
  window.addEventListener("mouseup", endStroke);
  canvas.addEventListener("touchstart", startStroke, { passive: false });
  canvas.addEventListener("touchmove", moveStroke, { passive: false });
  window.addEventListener("touchend", endStroke);

  // remote cursor UI
  const remoteEls = new Map();
  function upsertCursor({ id, x, y, color }) {
    if (id === state.myId) return;
    let el = remoteEls.get(id);
    if (!el) {
      el = document.createElement("div");
      el.className = "remote-cursor";
      el.style.borderColor = color || "#333";
      el.textContent = id.slice(0, 4);
      remoteEls.set(id, el);
      cursorsLayer.appendChild(el);
    }
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    el.style.background = color ? `${color}99` : "rgba(0,0,0,0.6)";
  }
  function removeCursor(id) {
    const el = remoteEls.get(id);
    if (el) { el.remove(); remoteEls.delete(id); }
  }

  // inbound events from server
  WS.on("init", ({ me, users, history }) => {
    state.myId = me.id;
    state.users = users || {};
    state.history = history || [];
    redrawAll();
    document.getElementById("users").textContent = `Users: ${Object.keys(users).length}`;
  });

  WS.on("user:join", ({ users }) => {
    document.getElementById("users").textContent = `Users: ${Object.keys(users).length}`;
  });
  WS.on("user:left", ({ id, users }) => {
    removeCursor(id);
    document.getElementById("users").textContent = `Users: ${Object.keys(users).length}`;
  });

  WS.on("draw:start", (stroke) => {
    // remote user started; optimistic: add if not exists
    // no-op here; we render on points/end
  });

  WS.on("draw:point", ({ strokeId, point, meta }) => {
    // draw incremental segment for remote
    const stroke = {
      id: strokeId,
      color: meta?.color || "#222",
      size: meta?.size || 4,
      type: meta?.type || "draw",
      points: [point], // incremental
    };
    drawStroke(ctx, stroke);
  });

  WS.on("draw:end", (stroke) => {
    // authoritative full stroke from server -> add & re-render last stroke neatly
    state.history.push(stroke);
    drawStroke(ctx, stroke);
  });

  WS.on("sync", ({ history }) => {
    state.history = history || [];
    redrawAll();
  });

  WS.on("cursor", (payload) => upsertCursor(payload));

  WS.on("latency", (ms) => {
    document.getElementById("latency").textContent = `${ms} ms`;
  });

  // expose a tiny API for main.js (UI)
  window.CanvasAPI = {
    setColor: (c) => state.color = c,
    setSize: (n) => state.size = +n,
    setMode: (m) => state.mode = m, // "brush" | "eraser"
    undo: () => WS.requestUndo(),
    redo: () => WS.requestRedo(),
    clear: () => WS.requestClear(),
  };
})();
