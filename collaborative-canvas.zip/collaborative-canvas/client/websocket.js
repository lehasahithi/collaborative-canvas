// websocket.js
(() => {
  const SOCKET_URL = location.origin; // same host
  const socket = io(SOCKET_URL, { transports: ["websocket"] });

  // small pub/sub for app-level events
  const handlers = {};
  function on(event, cb) {
    (handlers[event] ||= []).push(cb);
  }
  function emitLocal(event, data) {
    (handlers[event] || []).forEach(cb => cb(data));
  }

  // incoming from server -> fan out locally
  ["init","draw:start","draw:point","draw:end","sync","cursor","user:join","user:left","meta"]
    .forEach(evt => socket.on(evt, payload => emitLocal(evt, payload)));

  // latency ping
  setInterval(() => {
    const t0 = performance.now();
    socket.volatile.emit("ping", null, () => {
      const dt = Math.round(performance.now() - t0);
      emitLocal("latency", dt);
    });
  }, 2000);

  // outward APIs for other modules
  window.WS = {
    on,
    sendDrawStart: (stroke) => socket.emit("draw:start", stroke),
    sendDrawPoint: (pt) => socket.volatile.emit("draw:point", pt),
    sendDrawEnd: (strokeId) => socket.emit("draw:end", { strokeId }),
    requestUndo: () => socket.emit("undo"),
    requestRedo: () => socket.emit("redo"),
    requestClear: () => socket.emit("clear"),
    sendCursor: (pos) => socket.volatile.emit("cursor", pos),
  };
})();
