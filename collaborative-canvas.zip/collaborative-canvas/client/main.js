// main.js — binds UI to canvas/websocket
(() => {
  const colorEl = document.getElementById("color");
  const sizeEl = document.getElementById("size");
  const brushBtn = document.getElementById("brush");
  const eraserBtn = document.getElementById("eraser");
  const undoBtn = document.getElementById("undo");
  const redoBtn = document.getElementById("redo");
  const clearBtn = document.getElementById("clear");

  function setActive(btn) {
    [brushBtn, eraserBtn].forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
  }

  colorEl.addEventListener("input", e => CanvasAPI.setColor(e.target.value));
  sizeEl.addEventListener("input", e => CanvasAPI.setSize(e.target.value));

  brushBtn.addEventListener("click", () => { CanvasAPI.setMode("brush"); setActive(brushBtn); });
  eraserBtn.addEventListener("click", () => { CanvasAPI.setMode("eraser"); setActive(eraserBtn); });

  undoBtn.addEventListener("click", () => CanvasAPI.undo());
  redoBtn.addEventListener("click", () => CanvasAPI.redo());
  clearBtn.addEventListener("click", () => {
    if (confirm("Clear canvas for everyone?")) CanvasAPI.clear();
  });

  // keyboard shortcuts
  window.addEventListener("keydown", (e) => {
    const ctrl = e.ctrlKey || e.metaKey;
    if (ctrl && e.key.toLowerCase() === "z") { e.preventDefault(); CanvasAPI.undo(); }
    if (ctrl && e.key.toLowerCase() === "y") { e.preventDefault(); CanvasAPI.redo(); }
    if (e.key.toLowerCase() === "b") { CanvasAPI.setMode("brush"); setActive(brushBtn); }
    if (e.key.toLowerCase() === "e") { CanvasAPI.setMode("eraser"); setActive(eraserBtn); }
  });

  // initial active
  setActive(brushBtn);
})();
// brush cursor preview
const cursorEl = document.createElement("div");
cursorEl.className = "cursor-circle";
document.body.appendChild(cursorEl);

document.addEventListener("mousemove", (e) => {
  cursorEl.style.left = e.clientX + "px";
  cursorEl.style.top = e.clientY + "px";
  cursorEl.style.width = sizeEl.value + "px";
  cursorEl.style.height = sizeEl.value + "px";
  cursorEl.style.borderColor = colorEl.value;
});
// --- Floating brush cursor preview ---
const cursorEl = document.createElement("div");
cursorEl.className = "cursor-circle";
document.body.appendChild(cursorEl);

const colorEl = document.getElementById("color");
const sizeEl = document.getElementById("size");

document.addEventListener("mousemove", (e) => {
  cursorEl.style.left = e.clientX + "px";
  cursorEl.style.top = e.clientY + "px";
  cursorEl.style.width = sizeEl.value + "px";
  cursorEl.style.height = sizeEl.value + "px";
  cursorEl.style.borderColor = colorEl.value;
});
