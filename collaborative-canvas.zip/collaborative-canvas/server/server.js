const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static(path.join(__dirname, "..", "client")));

const users = {}; // id -> { color }
let history = []; // array of strokes { id, userId, color, size, type, points[] }
let redoStack = [];

// util
const rndColor = () => "#" + Math.floor(Math.random()*0xffffff).toString(16).padStart(6, "0");

io.on("connection", (socket) => {
  users[socket.id] = { color: rndColor() };

  // init: tell newcomer their id, current users, and full history
  socket.emit("init", { me: { id: socket.id }, users, history });
  socket.broadcast.emit("user:join", { users });

  // low-latency ping
  socket.on("ping", (_null, ack) => ack && ack());

  // drawing lifecycle
  socket.on("draw:start", (stroke) => {
    // nothing stored yet; we store final stroke on "draw:end"
    // optionally broadcast meta for live segment rendering
    socket.broadcast.emit("draw:start", stroke);
  });

  socket.on("draw:point", ({ strokeId, point }) => {
    // forward incremental segments with meta (color/size/type) for better rendering
    const user = users[socket.id] || {};
    socket.broadcast.volatile.emit("draw:point", {
      strokeId,
      point,
      meta: { color: user.color, size: point.size, type: point?.type }
    });
  });

  socket.on("draw:end", ({ strokeId }) => {
    // we didn’t receive the full stroke points from client in pieces here,
    // so we’ll request the client to send the compiled stroke back if needed.
    // Simpler approach: client already has the full stroke and sends it via draw:end.
    // => adjust: allow draw:end to also send the final stroke object.
  });

  // To keep it simple and correct, accept full stroke on draw:end:
  socket.removeAllListeners("draw:end");
  socket.on("draw:end", (stroke) => {
    if (!stroke || !stroke.points || !stroke.points.length) return;
    // server is source of truth
    redoStack = [];
    history.push(stroke);
    io.emit("draw:end", stroke);
  });

  // undo/redo (global)
  socket.on("undo", () => {
    if (!history.length) return;
    const last = history.pop();
    redoStack.push(last);
    io.emit("sync", { history });
  });

  socket.on("redo", () => {
    if (!redoStack.length) return;
    const s = redoStack.pop();
    history.push(s);
    io.emit("sync", { history });
  });

  socket.on("clear", () => {
    history = [];
    redoStack = [];
    io.emit("sync", { history });
  });

  // cursors
  socket.on("cursor", ({ x, y }) => {
    const color = users[socket.id]?.color;
    socket.broadcast.volatile.emit("cursor", { id: socket.id, x, y, color });
  });

  socket.on("disconnect", () => {
    delete users[socket.id];
    io.emit("user:left", { id: socket.id, users });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`✅ Server on http://localhost:${PORT}`));
